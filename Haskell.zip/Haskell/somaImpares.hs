somaImpares :: [Int]->Int
somaImpares [] = 0
somaImpares (x:xs)
 | x `mod` 2 /= 0 = x + somaImpares xs
 | otherwise = somaImpares xs
