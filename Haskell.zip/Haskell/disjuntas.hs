disjuntas :: [Int]->[Int]->Bool
disjuntas [] _= True
disjuntas (a:x) y = if(verifica a y == True) then disjuntas x y else False

verifica _ [] = True
verifica a (b:y) = if( a == b) then False else verifica a y
