binario :: Int->[Int]
binario 0 = []
binario a
 | (a `mod` 2)==0 = (binario (div a 2)) ++[0]
 | otherwise = (binario (div a 2)) ++[1]

