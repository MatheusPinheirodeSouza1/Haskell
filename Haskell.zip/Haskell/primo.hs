primo :: Int -> Bool
primo 1 = True
primo x = verifica x (x-1)

verifica a 1 = True
verifica a b = if ( a `mod` b == 0) then False else verifica a (b-1)
