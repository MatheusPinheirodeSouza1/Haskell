distintos :: [Int]->Bool
distintos [] = True
distintos (a:x) = if(verifica a x == True) then distintos x else False

verifica _ [] = True
verifica a (b:y) = if( a == b) then False else verifica a y
