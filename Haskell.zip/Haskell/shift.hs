shift :: Int->[Int]->[Int]
shift b a = primeiro b a ++ segundo b a

primeiro b [] = [] 
primeiro b (a:x) = if(b==0) then [a] ++ primeiro b x else primeiro (b-1) x

segundo 0 _ = [] 
segundo b (a:x) = [a] ++ segundo (b-1) x
