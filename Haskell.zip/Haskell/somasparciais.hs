somasparciais :: [Int]->[Int]
somasparciais [] = []
somasparciais (a:x) = somas a x 

somas a [] = [a]
somas a (b:y) = [a] ++ somas (a+b) y 
