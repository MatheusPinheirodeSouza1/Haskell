perfeito :: Int -> Bool
perfeito 0 = False
perfeito 1 = False
perfeito a = if ( soma a (a-1) == a ) then True else False

soma _ 1 = 1
soma x z = if ( x `mod` z == 0) then z + soma x (z-1) else soma x (z-1)
