intercalar :: [Int]->[Int]->[Int]
intercalar [] [] = []
intercalar a b = ordernar a b

ordernar [] []= []
ordernar (a:x) [] =  [a] ++ ordernar x []
ordernar [] (b:y) = [b] ++ ordernar [] y 
ordernar (a:x) (b:y) = if(a<b) then [a] ++ ordernar x (b:y) else [b] ++ ordernar (a:x) y 
