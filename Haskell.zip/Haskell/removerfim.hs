removerfim :: Int->[Int]->[Int]
removerfim n a = remover ((length a) - n) a 

remover 0 _ = [] 
remover b (a:x) = [a] ++ remover (b-1) x


