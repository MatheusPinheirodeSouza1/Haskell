palindromo :: [Int]->Bool
palindromo [] = True
palindromo x = verifica x (inverte x)

verifica [] [] = True
verifica (a:x) (b:y) = if( a == b) then verifica x y else False

inverte []= []
inverte (a:x) = inverte x ++ [a]
